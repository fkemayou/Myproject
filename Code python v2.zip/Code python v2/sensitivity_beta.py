import numpy as np
import figures as fig
import params as par

# Définition des conditions initiales
y0 = [100, 100, 1000, 10]

# Définition de la plage de temps
t = np.linspace(0, 300, 1001)

BI = 0
# ⚠️⚠️⚠️⚠️ Spécifiez le chemin complet de vos fichiers
### OCP_data 
chemin_temps1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/discretization_times.export"
chemin_variableS1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/S.export"
chemin_variableI1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/I.export"
chemin_variableN1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/N.export"
chemin_variableu1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/u.export"


t1 = np.loadtxt(chemin_temps1)
S1 = np.loadtxt(chemin_variableS1)
I1 = np.loadtxt(chemin_variableI1)
N1 = np.loadtxt(chemin_variableN1)
u1 = np.loadtxt(chemin_variableu1)

# OCP - Increased beta
chemin_temps2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_betatext/discretization_times.export"
chemin_variableS2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_betatext/S.export"
chemin_variableI2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_betatext/I.export"
chemin_variableN2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_betatext/N.export"
chemin_variableu2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_betatext/u.export"

t2 = np.loadtxt(chemin_temps2)
S2 = np.loadtxt(chemin_variableS2)
I2 = np.loadtxt(chemin_variableI2)
N2 = np.loadtxt(chemin_variableN2)
u2 = np.loadtxt(chemin_variableu2)

# OCP - Reduced beta
chemin_temps3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_betatext/discretization_times.export"
chemin_variableS3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_betatext/S.export"
chemin_variableI3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_betatext/I.export"
chemin_variableN3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_betatext/N.export"
chemin_variableu3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_betatext/u.export"

t3 = np.loadtxt(chemin_temps3)
S3 = np.loadtxt(chemin_variableS3)
I3 = np.loadtxt(chemin_variableI3)
N3 = np.loadtxt(chemin_variableN3)
u3 = np.loadtxt(chemin_variableu3)




fig.figure_Sensitivity_beta_plot(t, S1, S2, S3,
                          r"Healthy roots $S$", r'$\mathbf{(a)}$',
                          "comparisonhealthy_roots_beta.pdf",
                          show_legend=True,
                          is_healthy_roots_figure=True)

fig.figure_Sensitivity_beta_plot(t, I1, I2, I3,
                          r"Infected roots $I$", r'$\mathbf{(b)}$',
                          "comparison_infected_roots_beta.pdf",
                          show_legend=False)

fig.figure_Sensitivity_beta_plot(t, N1, N2, N3,
                           r"Total nematodes $N$", r'$\mathbf{(c)}$',
                           "comparison_total_nematodes_beta.pdf",
                           show_legend=False,
                           format_yaxis=True)

fig.figure_Sensitivity_beta_plot(t, u1, u2, u3,
                           r"Optimal control $u^\star$", r'$\mathbf{(b)}$',
                           "comparison_optimal_control_beta.pdf",
                           show_legend=False,
                           is_control_figure=True,
                           apply_ylim=False)


################# Calcul des couts de controle 

A1 = np.trapz(-par.BS * S1, t1)
A2 = np.trapz(par.Bu * u1, t1)
A = np.trapz(par.Bu * u1 - par.BS * S1, t1)

B1 = np.trapz(-par.BS * S2, t2)
B2 = np.trapz(par.Bu * u2, t2)
B = np.trapz(par.Bu * u2 - par.BS * S2, t1)

C1 = np.trapz(-par.BS * S3, t3)
C2 = np.trapz(par.Bu * u3, t3)
C = np.trapz(par.Bu * u3 - par.BS * S3, t1)


print("OCP: red curves - l'integrale de -BS*S:", A1)
print("OCP: red curves - l'integrale de Bu*u:", A2)
print("0CP: red curves - l'integrale de Bu*u - BS*S:", A)

print("OCP: teal curves - l'integrale de -BS*S:", B1)
print("OCP: teal curves - l'integrale de Bu*u:", B2)
print("0CP: teal curves - l'integrale de Bu*u - BS*S:", B)

print("OCP: brown curves - l'integrale de -BS*S:", C1)
print("OCP: brown curves - l'integrale de Bu*u:", C2)
print("0CP: brown curves - l'integrale de Bu*u - BS*S:", C)



