from scipy.integrate import odeint
import numpy as np
import functions as fu
import figures as fig

# Paramètres du modèle
t = np.linspace(0, 300, 1001)  # Points de temps pour la simulation
y0 = [100, 100, 1000, 0]      # Conditions initiales

# Résolution du système pour quelques valeurs de u
u_values = np.linspace(0, 0.8, 1001)
final_variable_values = []

for u0 in u_values:
    sol = odeint(fu.min_cocp, y0, t, args=(u0,))
    final_variable_values.append(sol[-1, 3])  # On prend la dernière valeur de Z

# Conversion en array numpy
final_variable_values = np.array(final_variable_values)

# Trouver le minimum
min_value = np.min(final_variable_values)
min_index = np.argmin(final_variable_values)
u_min = u_values[min_index]

# Trouver le maximum
max_value = np.max(final_variable_values)
max_index = np.argmax(final_variable_values)
u_max = u_values[max_index]

# Affichage du résultat
print(f'Le minimum de la fonction est {min_value:.2f} pour u = {u_min:.2f}.')
print(f'Le maximum de la fonction est {max_value:.2f} pour u = {u_max:.2f}.')

# Affichage graphique
fig.figure_min_cocp_plot(u_values, final_variable_values, "criterion.pdf")
#plt.savefig("resultat_min_max.png", dpi=300, bbox_inches="tight")
#plt.show()