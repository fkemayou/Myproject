import numpy as np
import params as  par 
import functions as fu
import figures as fig
from scipy.optimize import fsolve, minimize_scalar

# ============================================================
# CALCUL DE I EN FONCTION DE u
# ============================================================

def solve_for_x2(x1):

    c1, c2, c3, c4, c5, c6, d4, R0, d3, d2, d1, d0 = fu.calculate_coefficients_socp(x1)

    def g(x2):
        return (
            d4 * x2**4
            + d3 * x2**3
            + d2 * x2**2
            + d1 * x2
            + d0
        )

    # Recherche de la racine
    sol = fsolve(g, 1000)[0]

    return float(sol)


# ============================================================
# FONCTION OBJECTIF
# ============================================================

def fun(x):

    # Ici x contient uniquement u
    x1 = float(np.asarray(x).reshape(-1)[0])

    # I est déterminé par l'équation d'équilibre
    x2 = solve_for_x2(x1)

    # Vérification physique
    if not np.isfinite(x2) or x2 < 0:
        return 1e20

    # Population de nématodes à l'équilibre
    N = (
        par.K * x2
        * (
            (par.r + par.c_rho * par.rho - par.nu) * x2
            + (par.r - par.nu) * par.alpha
        )
        / (
            (par.r + par.c_rho * par.rho) * x2
            + par.r * par.alpha
        )
    )

    # Biomasse saine
    S = par.Lambda / (par.beta * (1 - x1) * N + par.mu)

    # Fonction objectif
    J = par.Bu * x1 - par.BS * S

    return float(J)


# ============================================================
# OPTIMISATION
# ============================================================

res = minimize_scalar(fun,
    bounds=(0, 0.8),
    method='bounded',
    options={
        'xatol': 1e-10,
        'maxiter': 1000
    }
)


# ============================================================
# SOLUTION OPTIMALE
# ============================================================

u_opt = res.x
I_opt = solve_for_x2(u_opt)

# Calcul de N et S à l'optimum
N_opt = (
    par.K * I_opt
    * (
        (par.r + par.c_rho * par.rho - par.nu) * I_opt
        + (par.r - par.nu) * par.alpha
    )
    / (
        (par.r + par.c_rho * par.rho) * I_opt
        + par.r * par.alpha
    )
)

S_opt = par.Lambda / (par.beta * (1 - u_opt) * N_opt + par.mu)

R0_opt = ((par.Lambda * par.beta * (1 - u_opt) * par.K) / par.mu**2) * (1 - par.nu / par.r)


# ============================================================
# AFFICHAGE DES RESULTATS
# ============================================================

print("\n======================================================")
print("                 SOLUTION OPTIMALE")
print("======================================================")

print("u optimal =", u_opt)
print("I optimal =", I_opt)
print("N optimal =", N_opt)
print("S optimal =", S_opt)
print("R0 optimal =", R0_opt)
print("Valeur de la fonction objectif =", res.fun)

print("======================================================\n")


# ============================================================
# CALCUL DE LA COURBE I(u)
# ============================================================

x1_values = np.linspace(0, 0.8, 1000)

x2_values = np.zeros_like(x1_values)

for i, x1 in enumerate(x1_values):

    try:
        x2 = solve_for_x2(x1)

        if np.isfinite(x2) and x2 >= 0:
            x2_values[i] = x2
        else:
            x2_values[i] = np.nan

    except:
        x2_values[i] = np.nan

# ============================================================
# CALCUL DE LA FONCTION OBJECTIF
# ============================================================

J_values = np.zeros_like(x1_values)

for i, x1 in enumerate(x1_values):

    try:
        J_values[i] = fun([x1])

    except:
        J_values[i] = np.nan

# ============================================================
# VERIFICATION DE L'OBJECTIF AUTOUR DU MINIMUM
# ============================================================

# print("\n======================================================")
# print("              VERIFICATION DU MINIMUM")
# print("======================================================")

# for u in [0.60, 0.65, 0.70, 0.75, 0.80]:

#     J = fun([u])

#     print(
#         "u = {:.2f}    J(u) = {:.10f}".format(u, J)
#     )

# print("======================================================")

# ============================================================
# FIGURE 1 : CONTRAINTE D'EQUILIBRE I(u)
# ============================================================

fig.figure_min_socp_plot(
    x1_values,
    x2_values,
    None,
    '$I$',
    'Constraint',
    u_opt=u_opt,
    I_opt=I_opt
)


# ============================================================
# FIGURE 2 : FONCTION OBJECTIF J(u)
# ============================================================

fig.figure_min_socp_plot(
    x1_values,
    None,
    J_values,
    '$\\mathcal{J}(u)$',
    'Objective function',
    u_opt=u_opt,
    J_opt=res.fun
)