import numpy as np
from scipy.integrate import odeint
import functions as fu
import figures as fig
import params as par


#Valeur de la penalite 
BI = 180

# Définition de la plage de temps
t = np.linspace(0, 300, 1001)

# Résolution du système d'équations différentielles
y_withoutc = odeint(fu.modeloriginal_eps, par.y01, t, args=(0.001,))

# ⚠️⚠️⚠️⚠️ Spécifiez le chemin complet de vos fichiers 
### OCP_data   
chemin_temps1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/discretization_times.export"
chemin_variableS = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/S.export"
chemin_variableI = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/I.export"
chemin_variableN = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/N.export"
chemin_variableM = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/M.export"
chemin_variableu = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/u.export"
chemin_adjointlambda1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/S_adjoint_state.export"
chemin_adjointlambda2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_full_system_with_penaltytext/I_adjoint_state.export"
# Importez les données depuis les fichiers
t1 = np.loadtxt(chemin_temps1)
S = np.loadtxt(chemin_variableS)
I = np.loadtxt(chemin_variableI)
N = np.loadtxt(chemin_variableN)
M = np.loadtxt(chemin_variableM)
u = np.loadtxt(chemin_variableu)
lambda1 = np.loadtxt(chemin_adjointlambda1)
lambda2 = np.loadtxt(chemin_adjointlambda2)


fig.figure_OCP_plot(t, S, y_withoutc[:,0],
                    "Healthy roots $S$", r'$\bf{(a)}$', 
                    "ocp_full_system_healthy_roots.pdf", 
                    show_legend=True, is_healthy_roots_figure=True)
fig.figure_OCP_plot(t, I, y_withoutc[:,1],
                    "Infected roots $I$",  r'$\bf{(b)}$', 
                    "ocp_full_system_infected_roots.pdf",
                    apply_ylim=True)
fig.figure_OCP_plot(t, N, y_withoutc[:,2],
                    "Total nematodes $N$",  r'$\bf{(c)}$', 
                    "ocp_full_system_total_nematodes.pdf", 
                    format_yaxis=True,
                    apply_ylim=True)
fig.figure_OCP_plot(t, M, y_withoutc[:,3],
                    "Free nematodes $N_F$",  r'$\bf{(d)}$', 
                    "ocp_full_system_total_nematodes.pdf", 
                    format_yaxis=True,
                    apply_ylim=True)
fig.figure_OCP_plot(t, u, None, 
                    "Optimal control $u^{\star}$", r'$\bf{(e)}$', 
                    "ocp_full_system_optimal_control.pdf", 
                    apply_ylim=True)



################# Calcul des couts de controle 


A1 = np.trapz(-par.BS * S, t1)
A2 = np.trapz(par.Bu * u, t1)
A3 = BI*I[-1]
A4 = sum(u) / 1001 
A = A1 + A2 + A3


print("OCP - l'integrale de -BS*S:", A1)
print("OCP - l'integrale de Bu*u:", A2)
print("OCP - penalite:", A3)
print("0CP - average:", A4)
print("0CP - l'integrale de Bu*u - BS*S + penalite:", A)



