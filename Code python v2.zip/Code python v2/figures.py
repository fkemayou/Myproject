import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter
from mpl_toolkits.axes_grid1.inset_locator import inset_axes


############################ Tikhonov Plots ###############################
 
def figure_Tikhonov_plot(t, y_original_eps_01, y_original_eps_001, y_original_eps_0001,
                  y_reduit, ylabel_text, fig_label, save_name, 
                  show_legend=False, format_yaxis=False):
     plt.figure(dpi=100)
     plt.rc('text', usetex=True)
     plt.plot(t, y_original_eps_01, "k", label=r"Original system$(\epsilon=0.1)$", linewidth=2.5)
     plt.plot(t, y_original_eps_001, "g", label=r"Original system$(\epsilon=0.01)$", linewidth=3.5)
     plt.plot(t, y_original_eps_0001, "b", label=r"Original system$(\epsilon=0.001)$", linewidth=2.5)
     if y_reduit is not None:
        plt.plot(t,y_reduit,"r--",label = "Reduced system",linewidth = 2.5)
     plt.xlabel('Time [days]', fontsize = 20)
     plt.ylabel(ylabel_text, fontsize=20)
     plt.xlim(left=0)
     plt.ylim(bottom=0)
     
     ax = plt.gca()
    
     ax.tick_params(axis='both', which='major', labelsize=16)
    
     ax.spines['top'].set_linewidth(2)
     ax.spines['right'].set_linewidth(2)
     ax.spines['bottom'].set_linewidth(2)
     ax.spines['left'].set_linewidth(2)
     
     if show_legend:
         plt.legend(fontsize=16)
         
     if format_yaxis:
         formatter = ScalarFormatter(useMathText=True)
         formatter.set_powerlimits((3, 3))
         plt.ticklabel_format(style='sci', axis='y', scilimits=(6, 6))
         
     plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], fig_label, 
             color='k', fontsize=20, ha='right', va='bottom')
     plt.savefig(save_name, bbox_inches='tight')
     plt.show()


################################## Forward birfucation Plots #################

def figure_Forward_plot(T0, sol1, sol2, sol3, sol4, save_name):
    plt.figure(dpi=100) 
    plt.rc('text', usetex=True)  
    plt.plot(T0, sol4, 'b', linewidth=2.5)
    plt.plot(T0, sol3, 'r', linewidth=2.5)
    plt.plot(T0, sol2, 'b', linewidth=2.5)
    plt.plot(T0, sol1, 'b', linewidth=2.5)
    plt.plot([0, 1], [0, 0], 'b--', [1, 9], [0, 0], 'r--', linewidth=6)
    plt.legend(['Stable', 'Unstable'], fontsize=20, loc='lower right', bbox_to_anchor=(0.9, 0)) #, loc='lower right', bbox_to_anchor=(0.9, 0)
    plt.xlim([0, 9])
    plt.xlabel("$\mathcal{R}$", fontsize=20)
    plt.ylabel("Infected roots $\overline{I}$", fontsize=20)
    plt.xlim(left=0)  # Limite infÃ©rieure en x
    plt.ylim(bottom=0)  # Limite infÃ©rieure en y
    # Récupérer le handle de l'axe actuel
    ax = plt.gca()
    # Ajuster la taille de la police des valeurs des axes
    ax.tick_params(axis='both', which='major', labelsize=16)
    
    # Ajuster l'épaisseur des lignes des axes
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    plt.xticks([0, 1, 5, 8.4], fontsize=20, fontweight='bold')
    plt.yticks([0, 200, 400, 600, 800], fontsize=20, fontweight='bold')
    # Vector color
    Vcolor = [[0, 0, 0]]
    
    # Vector of R0 for backward bifurcation
    VR0 = [8.4]
    
    # Tracer les lignes pointillÃ©es
    for i, color in enumerate(Vcolor):
        plt.plot([VR0[i], VR0[i]], [0, 1000], linestyle=':', color=color, linewidth=2.5)
    
    # Masquer les lignes dans la lÃ©gende
    #plt.legend().set_visible(False)
    
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], r'$\bf{(a)}$', color='k', fontsize=20, ha='right', va='bottom')
    
    # Création de l'axe secondaire pour le zoom
    axins = inset_axes(
        ax,
        width="42%",
        height="42%",
        loc="upper left",
        bbox_to_anchor=(0.1, -0.02, 1, 1),
        bbox_transform=ax.transAxes
    )

    mask = (T0 >= 0.7) & (T0 <= 1.3)

    axins.plot(T0[mask], sol4[mask], 'b', linewidth=2)
    axins.plot(T0[mask], sol3[mask], 'r', linewidth=2)
    axins.plot(T0[mask], sol2[mask], 'b', linewidth=2)
    axins.plot(T0[mask], sol1[mask], 'b', linewidth=2)

    # Equilibre exempt de nématodes I = 0
    # Stable pour R < 1
    axins.plot(
        [0, 1],
        [0, 0],
        'b--',
        linewidth=3
    )

    # Instable pour R > 1
    axins.plot(
        [1, 1.3],
        [0, 0],
        'r--',
        linewidth=3
    )

    # Seuil de bifurcation R = 1
    axins.axvline(
        x=1,
        color='black',
        linestyle=':',
        linewidth=1.8
    )

    # Limites du zoom
    axins.set_xlim(0.7, 1.3)
    axins.set_ylim(0, 20)

    # Étiquettes du zoom
    axins.set_xlabel(r'$\mathcal{R}$', fontsize=11)
    axins.set_ylabel(r'$\overline{I}$', fontsize=11, labelpad=-1)

    # Taille des graduations
    axins.tick_params(
        axis='both',
        which='major',
        labelsize=9
    )

    # Annotation du seuil
    axins.text(
        1.02,
        15,
        r'$\mathcal{R}=1$',
        fontsize=11,
        ha='left'
    )
    
    plt.savefig("Forward_bifurcation.pdf", bbox_inches='tight')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()

#################################### Forward birfucation - Satbility Plots ###########

def figure_Forward_stability_plot(t, y_1, y_2, save_name, show_legend=False):    
    plt.figure(dpi=100)
    plt.plot(t,y_1,"k",label = "$I_0=1500$",linewidth = 2.5)
    plt.plot(t,y_2,"k--",label = "$I_0=50$",linewidth = 2.5)
    plt.xlabel('Time [days]', fontsize = 20)
    plt.ylabel("Infected roots $I$", fontsize=20)
    plt.xlim(left=0)  # Limite inférieure en x
    plt.ylim(bottom=0)  # Limite inférieure en y
    # Récupérer le handle de l'axe actuel
    ax = plt.gca()
    # Ajuster la taille de la police des valeurs des axes
    ax.tick_params(axis='both', which='major', labelsize=16)
    
    # Ajuster l'épaisseur des lignes des axes
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    
    if show_legend:  # Afficher la légende seulement si show_legend=True
        plt.legend(fontsize=20)
    #plt.yticks([0, 500, 1000, 1500, 2000], fontsize=20, fontweight='bold')
    #plt.legend()
    # Ajouter le numéro de la figure en tête
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], r'$\bf{(b)}$', color='k', fontsize=20, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()
    
##################################  Backward birfucation Plots ##############
def figure_Backward_plot(T0, sol1, sol2, sol3, sol4, save_name):
    plt.figure(dpi=100) 
    plt.rc('text', usetex=True)  
    plt.plot(T0, sol3, 'b', linewidth=2.5, label='Stable')
    plt.plot(T0, sol4, 'r', linewidth=2.5, label='Unstable')
    plt.plot(T0, sol1, 'b', linewidth=2.5)
    plt.plot(T0, sol2, 'b', linewidth=2.5)
    plt.axvspan(0.43, 1, color='gray', alpha=0.3, label='Bistability region')
    plt.plot([0, 1], [0, 0], 'b--', [1, 3.5], [0, 0], 'r--', linewidth=6)
    plt.legend(fontsize=20)
    plt.xlim([0, 3.5])
    plt.xlabel("$\mathcal{R}$", fontsize = 20)
    plt.ylabel("Infected roots $\overline{I}$", fontsize=20)
    plt.xlim(left=0) 
    plt.ylim(bottom=0) 
    ax = plt.gca()
    ax.tick_params(axis='both', which='major', labelsize=16)
    
    
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    plt.xticks([0, 0.5, 1, 2, 3.5])
    plt.annotate(
        r'$\xi$',
        xy=(0.43, 0),           # pointe vers le seuil
        xytext=(0.15, 15),     # position du texte
        fontsize=20,
        ha='left',
        arrowprops=dict(
            arrowstyle='->',
            lw=1.5,
            color='black'
        )
    )
    
    # Vector color
    Vcolor = [[0, 0, 0]]
    
    # Vector of R0 for backward bifurcation
    VR0 = [0.5]
    
    # Tracer les lignes pointillées
    for i, color in enumerate(Vcolor):
        plt.plot([VR0[i], VR0[i]], [0, 90], linestyle=':', color=color, linewidth=2.5)
    
    # plt.text(
    #     VR0[i] + 0.03,
    #     70,
    #     r'$\xi$',
    #     ha='left',
    #     va='bottom',
    #     fontsize=16
    # )
    
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], r'$\bf{(a)}$', color='k', fontsize=20, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()
    

################################### Backward birfucation - Bi-stability1 Plots #########

def figure_Backward_bi_satbilty1_plot(t, y_1, y_2, save_name, show_legend=False):
    plt.figure(dpi=100)
    plt.plot(t, y_1,"k--",label = "$I_0=12$",linewidth = 2.5)
    plt.plot(t,y_2,"k",label = "$I_0=40$",linewidth = 2.5)
    plt.xlabel('Time [days]', fontsize = 20)
    plt.ylabel("Infected roots $I$", fontsize=20)
    plt.xlim(left=0) 
    plt.ylim(bottom=0)
    
    ax = plt.gca()
    ax.tick_params(axis='both', which='major', labelsize=16)
    
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    
    if show_legend:  # Afficher la légende seulement si show_legend=True
        plt.legend(fontsize=20)
    
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], r'$\bf{(b)}$', color='k', fontsize=20, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()
    

################################ Backward birfucation - Bi-stability2 Plots ######### 
    
def figure_Backward_bi_satbilty2_plot(t, y_1, y_2, y_3, y_4, ylabel_text, fig_label, 
                    save_name, show_legend=False, format_yaxis=False):
    plt.figure(dpi=100)
    plt.plot(t,y_1,"b",label = "$I_0=2$",linewidth = 2.5)
    plt.plot(t,y_2,"g",label = "$I_0=12$",linewidth = 2.5)
    plt.plot(t,y_3,"k",label = "$I_0=30$",linewidth = 2.5)
    plt.plot(t,y_4,"r",label = "$I_0=40$",linewidth = 2.5)
    plt.xlabel('Time [days]', fontsize = 20)
    plt.ylabel(ylabel_text, fontsize=20)
    plt.xlim(left=0)
    plt.ylim(bottom=0)

    ax = plt.gca()

    ax.tick_params(axis='both', which='major', labelsize=16)

    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    if show_legend:  # Afficher la légende seulement si show_legend=True
        plt.legend(fontsize=20)
        
    # Appliquer le formatage scientifique sur l'axe Y si demandé
    if format_yaxis:
        plt.gca().yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
        plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    
    #  Ajouter le numéro de la figure en haut à droite
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], fig_label, 
            color='k', fontsize=16, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()

################################### OCP Plots #########################

def figure_OCP_plot(t, OCP_data, y_beta2_non_nul, ylabel_text, fig_label, 
                    save_name, show_legend=False, format_yaxis=False, 
                    is_healthy_roots_figure=False, apply_ylim=True):    
    plt.figure(dpi=100)
    plt.rc('text', usetex=True)
    plt.plot(t, OCP_data, 'r', label=r"with control", linewidth=2.5)
    # # Nouvelle courbe
    # if additional_data is not None:
    #     plt.plot(t, additional_data, color='purple', 
    #              label=r" $B_u =12800$", linewidth=2.5)
    if y_beta2_non_nul is not None:
       plt.plot(t, y_beta2_non_nul, 'k', label=r"without control", linewidth=2.5)
   
    plt.xlabel('Time [days]', fontsize=20)
    plt.ylabel(ylabel_text, fontsize=20)
    plt.xlim(left=0)
    if apply_ylim:
       plt.ylim(bottom=0)
    ax = plt.gca()
    # Ajuster la taille de la police des valeurs des axes
    ax.tick_params(axis='both', which='major', labelsize=16)
    
    # Ajuster l'épaisseur des lignes des axes
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    
    # Si c'est la première figure, ajouter la ligne horizontale et l'annotation
    #if save_name == "ocp_with_penalty_healthy_roots.pdf":
    if is_healthy_roots_figure:
       plt.ylim([0, 6200])  # Limites de l'axe y pour cette figure spécifique
       plt.axhline(y=6000, color='gray', linestyle='--', linewidth=2.5, label=r"without pest")
       plt.text(20, 5450, r'$S^0$', color='gray', fontsize=16, ha='right', va='bottom')
    
    # if show_legend:
    #      plt.legend(
    #     fontsize=16,
    #     ncol=2,              # 2 colonnes
    #     frameon=True,        # cadre rectangulaire
    #     loc='best',
    #     columnspacing=1.5,   # espace entre les colonnes
    #     handletextpad=0.5,   # espace entre symbole et texte
    #     borderpad=0.3        # marge intérieure du cadre
    # )
         
    if show_legend:  # Afficher la légende seulement si show_legend=True
        plt.legend(fontsize=16)
        
    # Appliquer le formatage scientifique sur l'axe Y si demandé
    if format_yaxis:
        plt.gca().yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
        plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    
    #  Ajouter le numéro de la figure en haut à droite
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], fig_label, 
            color='k', fontsize=20, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()
    
    
    
################################### Sensitivity_beta - OCP Plots #####################

def figure_Sensitivity_beta_plot(t, y_OCP, y_SOCP, y_COCP, ylabel_text, fig_label,
                          save_name, show_legend=False, format_yaxis=False,
                          is_healthy_roots_figure=False, is_control_figure=False,
                          apply_ylim=True):
    plt.figure(dpi=100)
    plt.rc('text', usetex=True)

    # Tracé des états ou des contrôles
    if is_control_figure:
        off = 1.0

        for u, c, label, offset in [
            (y_OCP, 'red', r'$\beta=10^{-7}$', 0),
            (y_SOCP, 'teal', r'$\beta=1.4\times10^{-7}$', off),
            (y_COCP, 'brown', r'$\beta=0.6\times10^{-7}$', 2*off)]:
            plt.step(
                t, u + offset, where='post',
                color=c, linewidth=2.5, label=label)

        plt.yticks(
            [0, 0.8, 1, 1.8, 2, 2.8],
            ['0', '0.8', '0', '0.8', '0', '0.8'])
        plt.ylim(-0.1, 2.95)

    else:
        plt.plot(
            t, y_OCP, color='red',
            label=r'$\beta=10^{-7}$', linewidth=2.5)
        plt.plot(
            t, y_SOCP, color='teal',
            label=r'$\beta=1.4\times10^{-7}$', linewidth=2.5)
        plt.plot(
            t, y_COCP, color='brown',
            label=r'$\beta=0.6\times10^{-7}$', linewidth=2.5)

        if apply_ylim:
            plt.ylim(bottom=0)

        if is_healthy_roots_figure:
            plt.ylim(0, 6200)
            plt.axhline(
                y=6000, color='gray', linestyle='--',
                linewidth=2.5, label='without pest')
            plt.text(
                20, 5450, r'$S^0$', color='gray',
                fontsize=16, ha='right', va='bottom')

    plt.xlabel('Time [days]', fontsize=20)
    plt.ylabel(ylabel_text, fontsize=20)
    plt.xlim(left=0)

    ax = plt.gca()
    ax.tick_params(axis='both', which='major', labelsize=16)

    for spine in ax.spines.values():
        spine.set_linewidth(2)

    if show_legend:
        plt.legend(fontsize=16)

    if format_yaxis:
        ax.yaxis.set_major_formatter(
            ScalarFormatter(useMathText=True))
        ax.ticklabel_format(
            style='sci', axis='y', scilimits=(0, 0))

     #  Ajouter le numéro de la figure en haut à droite
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], fig_label, 
             color='k', fontsize=20, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()
    

################################### Sensitivity_control_cost_Bu - OCP Plots #####################

def figure_Sensitivity_control_cost_Bu_plot(t, y_OCP, y_SOCP, y_COCP, y_withoutc, 
                          ylabel_text, fig_label, save_name, show_legend=False, 
                          format_yaxis=False, is_healthy_roots_figure=False, 
                          is_control_figure=False, apply_ylim=True):
    plt.figure(dpi=100)
    plt.rc('text', usetex=True)

    # Tracé des états ou des contrôles
    if is_control_figure:
        off = 1.0

        for u, c, label, offset in [
            (y_OCP, 'red', r'$B_u=7800$', 0),
            (y_SOCP, 'blue', r'$B_u=12800$', 2*off),
            (y_COCP, 'purple', r'$B_u=2800$', off)]:
            plt.step(
                t, u + offset, where='post',
                color=c, linewidth=2.5, label=label)

        plt.yticks(
            [0, 0.8, 1, 1.8, 2, 2.8],
            ['0', '0.8', '0', '0.8', '0', '0.8'])
        plt.ylim(-0.1, 2.95)

    else:
        plt.plot(
            t, y_OCP, color='red',
            label=r'$B_u=7800$', linewidth=2.5)
        plt.plot(
            t, y_COCP, color='purple',
            label=r'$B_u=12800$', linewidth=2.5)
        plt.plot(
            t, y_SOCP, color='blue',
            label=r'$B_u=2800$', linewidth=2.5)
        
        if y_withoutc is not None:
           plt.plot(t, y_withoutc, 'k', label=r"without control", linewidth=2.5)

        if apply_ylim:
            plt.ylim(bottom=0)

        if is_healthy_roots_figure:
            plt.ylim(0, 6200)
            plt.axhline(
                y=6000, color='gray', linestyle='--',
                linewidth=2.5, label='without pest')
            plt.text(
                20, 5450, r'$S^0$', color='gray',
                fontsize=16, ha='right', va='bottom')

    plt.xlabel('Time [days]', fontsize=20)
    plt.ylabel(ylabel_text, fontsize=20)
    plt.xlim(left=0)

    ax = plt.gca()
    ax.tick_params(axis='both', which='major', labelsize=16)

    for spine in ax.spines.values():
        spine.set_linewidth(2)

    if show_legend:
         plt.legend(
        fontsize=16,
        ncol=2,              # 2 colonnes
        frameon=True,        # cadre rectangulaire
        loc='best',
        columnspacing=1.5,   # espace entre les colonnes
        handletextpad=0.5,   # espace entre symbole et texte
        borderpad=0.3        # marge intérieure du cadre
    )

    if format_yaxis:
        ax.yaxis.set_major_formatter(
            ScalarFormatter(useMathText=True))
        ax.ticklabel_format(
            style='sci', axis='y', scilimits=(0, 0))

     #  Ajouter le numéro de la figure en haut à droite
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], fig_label, 
             color='k', fontsize=20, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()
    
################################### Comparison - OCP Plots #####################

def figure_Comparison_plot(t, y_OCP, y_SOCP, y_COCP, y_AOCP, y_withoutc, ylabel_text, fig_label, 
                    save_name, show_legend=False, format_yaxis=False, 
                    is_healthy_roots_figure=False, is_control_figure=False,
                    apply_ylim=True):    
    plt.figure(dpi=100)
    plt.rc('text', usetex=True)
    plt.plot(t, y_OCP, 'r', label=r"ocp",  linewidth=2.5)
    plt.plot(t, y_SOCP, 'g', label=r"socp",  linewidth=2.5)
    plt.plot(t, y_COCP, 'm', label=r"cocp",  linewidth=2.5)
    if y_AOCP is not None:
        plt.plot(t, y_AOCP, 'y', label=r"without control", linewidth=2.5)
    if y_withoutc is not None:
       plt.plot(t, y_withoutc, 'k', label=r"without control", linewidth=2.5)
    plt.xlabel('Time [days]', fontsize=20)
    plt.ylabel(ylabel_text, fontsize=20)
    plt.xlim(left=0)  # Limite inférieure en x
    if apply_ylim:
        plt.ylim(bottom=0)
    ax = plt.gca()
    # Ajuster la taille de la police des valeurs des axes
    ax.tick_params(axis='both', which='major', labelsize=16)
    
    # Ajuster l'épaisseur des lignes des axes
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    
    # Si c'est la première figure, ajouter la ligne horizontale et l'annotation
    #if save_name == "ocp_with_penalty_healthy_roots.pdf":
    if is_healthy_roots_figure:
        plt.ylim([0, 6200])  # Limites de l'axe y pour cette figure spécifique
        plt.axhline(y=6000, color='gray', linestyle='--', linewidth=2.5, label=r"without pest")
        plt.text(20, 5450, r'$S^0$', color='gray', fontsize=16, ha='right', va='bottom')
        
    if is_control_figure:
        plt.plot([0, 300], [0.555, 0.555], 'y', linewidth=2.5)
    
    if show_legend:
         plt.legend(
        fontsize=16,
        ncol=2,              # 2 colonnes
        frameon=True,        # cadre rectangulaire
        loc='best',
        columnspacing=1.5,   # espace entre les colonnes
        handletextpad=0.5,   # espace entre symbole et texte
        borderpad=0.3        # marge intérieure du cadre
    )
    
    #if show_legend:  # Afficher la légende seulement si show_legend=True
    #    plt.legend(fontsize=16)
        
    # Appliquer le formatage scientifique sur l'axe Y si demandé
    if format_yaxis:
        plt.gca().yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
        plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    
    #  Ajouter le numéro de la figure en haut à droite
    plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], fig_label, 
            color='k', fontsize=20, ha='right', va='bottom')
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()
    
    
################################ Periodic - OCP Plots #################

def figure_Periodic_plot(t, y_OCP, y_SOCP, y_COCP, y_AOCP, y_withoutc, y_POCP, ylabel_text, fig_label, 
                    save_name, show_legend=False, format_yaxis=False, 
                    is_healthy_roots_figure=False, is_control_figure=False,
                    apply_ylim=True):  
     plt.figure(dpi=100)
     plt.rc('text', usetex=True)
     plt.plot(t, y_OCP, 'r', label="_nolegend_",  linewidth=2.5)
     plt.plot(t, y_SOCP, 'g', label=r"static-OCP",  linewidth=2.5)
     plt.plot(t, y_COCP, 'm', label=r"constant-OCP",  linewidth=2.5)
     if y_AOCP is not None:
         plt.plot(t, y_AOCP, 'y', label=r"average-OCP", linewidth=2.5)
     if y_withoutc is not None:
        plt.plot(t, y_withoutc, 'k', label="_nolegend_", linewidth=2.5)
     plt.plot(t, y_POCP, color='blue', linestyle='--', label=r"periodic-OCP",
             linewidth=2.5) 
     plt.xlabel('Time [days]', fontsize=20)
     plt.ylabel(ylabel_text, fontsize=20)
     plt.xlim(left=0)  # Limite inférieure en x
     if apply_ylim:
         plt.ylim(bottom=0)
     ax = plt.gca()
     # Ajuster la taille de la police des valeurs des axes
     ax.tick_params(axis='both', which='major', labelsize=16)
     
     # Ajuster l'épaisseur des lignes des axes
     ax.spines['top'].set_linewidth(2)
     ax.spines['right'].set_linewidth(2)
     ax.spines['bottom'].set_linewidth(2)
     ax.spines['left'].set_linewidth(2)
     
     # Si c'est la première figure, ajouter la ligne horizontale et l'annotation
     #if save_name == "ocp_with_penalty_healthy_roots.pdf":
     if is_healthy_roots_figure:
         plt.ylim([0, 6200])  # Limites de l'axe y pour cette figure spécifique
         plt.axhline(y=6000, color='gray', linestyle='--', linewidth=2.5, label="_nolegend_")
         plt.text(20, 5450, r'$S^0$', color='gray', fontsize=16, ha='right', va='bottom')
         
     if is_control_figure:
         plt.plot([0, 300], [0.412, 0.412], 'y', linewidth=2.5)
     
     #if show_legend:  # Afficher la légende seulement si show_legend=True
     #    plt.legend(fontsize=16)
     if show_legend:
          plt.legend(
         fontsize=16,
         ncol=2,              # 2 colonnes
         frameon=True,        # cadre rectangulaire
         loc='best',
         columnspacing=1.5,   # espace entre les colonnes
         handletextpad=0.5,   # espace entre symbole et texte
         borderpad=0.3        # marge intérieure du cadre
     )
              
     # Appliquer le formatage scientifique sur l'axe Y si demandé
     if format_yaxis:
         plt.gca().yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
         plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
     
     #  Ajouter le numéro de la figure en haut à droite
     plt.text(1.01 * plt.xlim()[1], 1.01 * plt.ylim()[1], fig_label, 
             color='k', fontsize=20, ha='right', va='bottom')
     plt.savefig(save_name, bbox_inches='tight')
     plt.show()
     
    
###################################### cocp #################################

def figure_min_cocp_plot(u_values, final_variable_values, save_name):
    plt.figure(dpi = 100)
    plt.plot(u_values, final_variable_values, label='Fonction objectif', linewidth=2)
    plt.xlabel('$u$', fontsize=20)
    plt.ylabel('$\mathcal{J}(u)$', fontsize=20)
    ax = plt.gca()
    ax.tick_params(axis='both', which='major', labelsize=16)
     
    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)
    plt.savefig(save_name, bbox_inches='tight')
    plt.show()


##################################### socp #################################

def figure_min_socp_plot(x1_values, x2_values, J_values,
                         ylabel_text, title_text,
                         u_opt=None, I_opt=None, J_opt=None):

    plt.figure(dpi=100)

    if x2_values is not None:
        plt.plot(x1_values, x2_values, 'b', linewidth=2.5)

        # Point optimal sur I(u)
        if u_opt is not None and I_opt is not None:
            plt.plot(u_opt, I_opt, 'ko', markersize=8)

            # Ligne verticale au niveau de l'optimum
            plt.axvline(
                u_opt,
                color='black',
                linestyle=':',
                linewidth=2
            )

    if J_values is not None:
        plt.plot(x1_values, J_values, 'r', linewidth=2.5)

        # Point optimal sur J(u)
        if u_opt is not None and J_opt is not None:
            plt.plot(u_opt, J_opt, 'ko', markersize=8)

            # Ligne verticale au niveau de l'optimum
            plt.axvline(
                u_opt,
                color='black',
                linestyle=':',
                linewidth=2
            )

    plt.xlabel('$u$', fontsize=20)
    plt.ylabel(ylabel_text, fontsize=20)

    ax = plt.gca()

    ax.tick_params(axis='both', which='major', labelsize=16)

    ax.spines['top'].set_linewidth(2)
    ax.spines['right'].set_linewidth(2)
    ax.spines['bottom'].set_linewidth(2)
    ax.spines['left'].set_linewidth(2)

    plt.title(title_text, fontsize=20)
    plt.show()