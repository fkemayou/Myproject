import numpy as np
from scipy.integrate import odeint
import functions as fu
import figures as fig
import params as par

tf = 300 # temps final
# Définition de la plage de temps
t = np.linspace(0, tf, 1001)

# Résolution du système d'équations différentielles
y_withoutc = odeint(fu.controlled_model, par.y0, t, args=(0,))

# ⚠️⚠️⚠️⚠️ Spécifiez le chemin complet de vos fichiers
### OCP_data 
chemin_temps1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/discretization_times.export"
chemin_variableS1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/S.export"
chemin_variableI1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/I.export"
chemin_variableN1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/N.export"
chemin_variableu1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exocpwithoutpenaltytext/u.export"


t1 = np.loadtxt(chemin_temps1)
S1 = np.loadtxt(chemin_variableS1)
I1 = np.loadtxt(chemin_variableI1)
N1 = np.loadtxt(chemin_variableN1)
u1 = np.loadtxt(chemin_variableu1)

# OCP - Increased Bu
chemin_temps2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_Butext/discretization_times.export"
chemin_variableS2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_Butext/S.export"
chemin_variableI2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_Butext/I.export"
chemin_variableN2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_Butext/N.export"
chemin_variableu2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_reduced_Butext/u.export"

t2 = np.loadtxt(chemin_temps2)
S2 = np.loadtxt(chemin_variableS2)
I2 = np.loadtxt(chemin_variableI2)
N2 = np.loadtxt(chemin_variableN2)
u2 = np.loadtxt(chemin_variableu2)

# OCP - Reduced Bu
chemin_temps3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_Butext/discretization_times.export"
chemin_variableS3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_Butext/S.export"
chemin_variableI3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_Butext/I.export"
chemin_variableN3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_Butext/N.export"
chemin_variableu3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1-Mainpaper\4. Codes\exOCP_no_penalty_increased_Butext/u.export"

t3 = np.loadtxt(chemin_temps3)
S3 = np.loadtxt(chemin_variableS3)
I3 = np.loadtxt(chemin_variableI3)
N3 = np.loadtxt(chemin_variableN3)
u3 = np.loadtxt(chemin_variableu3)


fig.figure_Sensitivity_control_cost_Bu_plot(t, S1, S2, S3, y_withoutc[:,0],
                          r"Healthy roots $S$", r'$\mathbf{(a)}$',
                          "comparisonhealthy_roots_beta.pdf",
                          show_legend=True,
                          is_healthy_roots_figure=True)

fig.figure_Sensitivity_control_cost_Bu_plot(t, I1, I2, I3,  y_withoutc[:,1], 
                          r"Infected roots $I$", r'$\mathbf{(b)}$',
                          "comparison_infected_roots_beta.pdf",
                          show_legend=False)

fig.figure_Sensitivity_control_cost_Bu_plot(t, N1, N2, N3,  y_withoutc[:,2], 
                           r"Total nematodes $N$", r'$\mathbf{(c)}$',
                           "comparison_total_nematodes_beta.pdf",
                           show_legend=False,
                           format_yaxis=True)

fig.figure_Sensitivity_control_cost_Bu_plot(t, u1, u2, u3, None,
                           r"Optimal control $u^\star$", r'$\mathbf{(d)}$',
                           "comparison_optimal_control_Bu.pdf",
                           show_legend=False,
                           is_control_figure=True,
                           apply_ylim=False)

################# Calcul des couts de controle 

A1 = np.trapz(-par.BS * S1, t1)
A2 = np.trapz(par.Bu * u1, t1)
A = np.trapz(par.Bu * u1 - par.BS * S1, t1)

Bu1 = 2800
B1 = np.trapz(-par.BS * S2, t2)
B2 = np.trapz(Bu1 * u2, t2)
B = np.trapz(Bu1 * u2 - par.BS * S2, t1)

Bu2 = 12800
C1 = np.trapz(-par.BS * S3, t3)
C2 = np.trapz(Bu2 * u3, t3)
C = np.trapz(Bu2 * u3 - par.BS * S3, t1)


print("OCP: red curves - l'integrale de -BS*S:", A1)
print("OCP: red curves - l'integrale de Bu*u:", A2)
print("0CP: red curves - l'integrale de Bu*u - BS*S:", A)


print("OCP: blue curves - l'integrale de -BS*S:", B1)
print("OCP: blue curves - l'integrale de Bu*u:", B2)
print("0CP: blue curves - l'integrale de Bu*u - BS*S:", B)

print("OCP: purple curves - l'integrale de -BS*S:", C1)
print("OCP: purple curves - l'integrale de Bu*u:", C2)
print("0CP: purple curves - l'integrale de Bu*u - BS*S:", C)
