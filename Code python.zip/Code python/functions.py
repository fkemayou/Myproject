import numpy as np
import params as par
import functions as fu

def modeloriginal_eps(y,t, eps):
   y1,y2,y3, y4 = y    
   dy1 = par.Lambda - (par.beta_F*y4 + par.beta_I*(y3-y4))*y1 - par.mu*y1;
   dy2 = (par.beta_F*y4+par.beta_I*(y3-y4))*y1 -par.mu*y2 - par.rho*(y3-y4)*(y2/(par.alpha+y2));
   dy3 = -par.nu_I*(y3-y4)+(par.r+par.c_rho*par.rho*(y2/(par.alpha+y2)))*(y3-y4)*(1-((y3-y4)/(par.K*y2)));
   dy4 = -(par.c_alpha/eps)*par.beta_F*(y1+par.eta*y2)*y4 + (par.gamma+par.gamma*((y3-y4)/(par.K*y2)))*(y3-y4) - par.nu_F*y4;
   
   return  dy1, dy2, dy3, dy4  


def modelreduit(y,t): 
    y1,y2,y3 = y    
    dy1 = par.Lambda - par.beta*y3*y1 - par.mu*y1
    dy2 = par.beta*y3*y1 - par.mu*y2 - par.rho*y3*(y2/(par.alpha+y2))
    dy3 = (par.r+par.c_rho*par.rho*(y2/(par.alpha+y2)))*y3*(1-(y3/(par.K*y2)))-par.nu_I*y3  
                                 
    return dy1, dy2, dy3 


def compute_bifurcation(vect_rh, is_forward=True):
    if is_forward:
        par.Lambda = 300  # Utilise les memes valeurs que dans params.py
        par.r = 0.15
    else:
        par.Lambda = 10  # on change ces parametres dans params.py
        par.r = 0.05
    sol1 = np.zeros_like(vect_rh, dtype=np.complex128)
    sol2 = np.zeros_like(vect_rh, dtype=np.complex128)
    sol3 = np.zeros_like(vect_rh, dtype=np.complex128)
    sol4 = np.zeros_like(vect_rh, dtype=np.complex128)
    Vect_R0 = np.zeros_like(vect_rh, dtype=np.complex128)
    T0 = np.zeros_like(vect_rh)

    for i, beta in enumerate(vect_rh):
        T0[i] = ((par.Lambda * beta * par.K) / par.mu ** 2) * (1 - (par.nu_I / par.r))
        R0 = T0[i]
        c1 = par.r + par.c_rho * par.rho - par.nu_I
        c2 = par.r + par.c_rho * par.rho
        c3 = par.r - par.nu_I
        c4 = c1 * c2
        c5 = c1 * c3
        c6 = c2 * c3
        d4 = - par.mu * par.K * beta * c4 - par.rho * beta * (par.K ** 2) * ((c1) ** 2)
        d3 = par.Lambda * beta * par.K * c4 - par.mu * par.alpha * beta * par.K * c4 - \
             par.mu * par.K * beta * par.r * par.alpha * c1 - par.mu * par.K * beta * par.alpha * c6 - \
            (par.mu ** 2) * ((c2) ** 2) - par.rho * beta * (par.K ** 2) * par.alpha * c5 - \
             par.rho * par.K * par.mu * c4 - par.rho * beta * (par.K ** 2) * par.alpha * c5
        d2 = par.Lambda * beta * par.K * par.alpha * c4 + \
             par.Lambda * beta * par.K * par.r * par.alpha * c1 + \
             par.Lambda * beta * par.K * par.alpha * c6 - par.mu * (par.alpha ** 2) * beta * par.K * par.r * c1 - \
             par.mu * (par.alpha ** 2) * beta * par.K * c6 - (par.mu ** 2) * par.alpha * ((c2) ** 2) - \
             par.mu * beta * par.K * par.r * (par.alpha ** 2) * c3 - 2 * (par.mu ** 2) * par.r * par.alpha * c2 - \
             par.rho * par.K * par.mu * par.r * par.alpha * c1 - \
             par.rho * beta * (par.K ** 2) * ((c3) ** 2) * (par.alpha ** 2) - par.rho * par.K * par.alpha * par.mu * c6
        d1 = par.Lambda * beta * par.K * par.r * (par.alpha ** 2) * c1 + \
             par.Lambda * beta * par.K * (par.alpha ** 2) * c6 + \
             par.Lambda * beta * par.K * par.r * (par.alpha ** 2) * c3 - \
             par.mu * (par.alpha ** 3) * beta * par.K * par.r * c3 - \
             2 * (par.mu ** 2) * par.r * (par.alpha ** 2) * c2 - ((par.mu * par.r * par.alpha) ** 2) - \
             par.rho * par.K * par.mu * par.r * (par.alpha ** 2) * c3
        d0 = (par.alpha * (par.mu * par.r * par.alpha) ** 2) * (R0 - 1)
        Vect_R0[i] = R0
        coef = [d4, d3, d2, d1, d0]
        sol = np.roots(coef)
        sol1[i] = sol[0]
        sol2[i] = sol[1]
        sol3[i] = sol[2]
        sol4[i] = sol[3]

        if np.imag(sol1[i]) != 0 or np.real(sol1[i]) < 0:
            sol1[i] = np.nan
        if np.imag(sol2[i]) != 0 or np.real(sol2[i]) < 0:
            sol2[i] = np.nan
        if np.imag(sol3[i]) != 0 or np.real(sol3[i]) < 0:
            sol3[i] = np.nan
        if np.imag(sol4[i]) != 0 or np.real(sol4[i]) < 0:
            sol4[i] = np.nan
            
    return sol1, sol2, sol3, sol4, Vect_R0, T0


def modelreduitBb1(y,t): 
    par.Lambda=10
    par.beta= 1.25e-6 
    par.r=0.05
    y1,y2,y3 = y    
    dy1 = par.Lambda - par.beta*y3*y1 - par.mu*y1
    dy2 = par.beta*y3*y1 - par.mu*y2 - par.rho*y3*(y2/(par.alpha+y2))
    dy3 = (par.r+par.c_rho*par.rho*(y2/(par.alpha+y2)))*y3*(1-(y3/(par.K*y2)))-par.nu_I*y3  
                                 
    return dy1, dy2, dy3 


def fullmodel(y,t):
    par.Lambda=10
    par.beta= 1.25e-6 
    par.r=0.05
    y1,y2,y3,y4 = y    
    dy1 = par.Lambda - par.beta*y3*y1 - par.mu*y1
    dy2 = par.beta*y3*y1 - par.mu*y2 - par.rho*y3*(y2/(par.alpha+y2))
    dy3 = (par.r+par.c_rho*par.rho*(y2/(par.alpha+y2)))*y3*(1-(y3/(par.K*y2)))-par.nu_I*y3  
    dy4 = (par.r+par.c_rho*par.rho*(y2/(par.alpha+y2)))*y4*(1-(y4/par.K))-(par.nu_I-par.mu)*y4-par.beta*y1*(y4**2)+par.rho*y4**2*(y2/(par.alpha+y2));
                                 
    return dy1, dy2, dy3, dy4

############################ Model with control

def controlled_model(y, t, u):
    dydt = np.zeros(3)
    dydt[0] = par.Lambda - (1-u)*par.beta_I*y[2]*y[0] - par.mu*y[0]
    dydt[1] = (1-u)*par.beta_I*y[2]*y[0] - par.mu*y[1] - par.rho*y[2]*(y[1]/(par.alpha+y[1]))
    dydt[2] = -par.nu_I*y[2] + (par.r+par.c_rho*par.rho*(y[1]/(par.alpha+y[1])))*y[2]*(1-(y[2]/(par.K*y[1])))
    return dydt


#################################### Periodic - OCP 

def control_sequence(t, temps0, temps1, temps2, temps3):
    # Calcul de la durée totale d'une période (temps1 + temps2)
    total_period_length = temps1 + temps2
    initial_period_length = temps0
    number_of_periods = 5
    
    elapsed_time = t

    # Si t est avant la fin de temps0, le contrôle est en 0
    if elapsed_time < initial_period_length:
        return 0
    else:
        elapsed_time -= initial_period_length 

        # Si t est dans la période finale (après les 5 périodes de temps1 + temps2), le contrôle est à 0
        if elapsed_time >= number_of_periods * total_period_length:
            return 0

        # Si on est dans les 5 périodes périodiques
        if elapsed_time < number_of_periods * total_period_length:
            period_index = int(elapsed_time / total_period_length)
            period_elapsed_time = elapsed_time - period_index * total_period_length
            
            # Contrôle en 0.8 pendant temps1, puis en 0 pendant temps2
            if period_elapsed_time < temps1:
                return 0.8
            else:
                return 0
            

def controlled_model_optimisation(y, t, temps0, temps1, temps2, temps3):
    y1, y2, y3 = y
    u = fu.control_sequence(t, temps0, temps1, temps2, temps3)
    dy1 = par.Lambda - par.beta_I * (1 - u) * y3 * y1 - par.mu * y1
    dy2 = par.beta_I * (1 - u) * y3 * y1 - par.mu * y2 - par.rho * y3 * (y2 / (par.alpha + y2))
    dy3 = (par.r + par.c_rho * par.rho * (y2 / (par.alpha + y2))) * y3 * (1 - (y3 / (par.K * y2))) - par.nu_I * y3
    return dy1, dy2, dy3


# Minimisation de la fonction objective: cas du Constant - OCP
def min_cocp(y, t, u):
    S, I, N, Z = y
    dSdt = par.Lambda - (1 - u) * par.beta * N * S - par.mu * S
    dIdt = (1 - u) * par.beta * N * S - par.mu * I - par.rho * N * (I / (par.alpha + I))
    dNdt = (par.r + par.c_rho * par.rho * (I / (par.alpha + I))) * N * (1 - (N / (par.K * I))) - par.nu_I * N
    dZdt = par.Bu * u - par.BS * S
    return [dSdt, dIdt, dNdt, dZdt]


# Calcul des coefficients: 
# minimisation de la fonction objective: cas du Static - ocp
def calculate_coefficients_socp(x1):
    c1 = par.r + par.c_rho * par.rho - par.nu_I
    c2 = par.r + par.c_rho * par.rho
    c3 = par.r - par.nu_I
    c4 = c1 * c2
    c5 = c1 * c3
    c6 = c2 * c3
    d4 = -par.mu * par.K * par.beta * (1 - x1) * c4 - par.rho * par.beta * (1 - x1) * (par.K ** 2) * ((c1) ** 2)
    R0 = ((par.Lambda * par.beta * (1 - x1) * par.K) / par.mu ** 2) * (1 - (par.nu_I / par.r))
    d3 = par.Lambda * par.beta * (1 - x1) * par.K * c4 - par.mu * par.alpha * par.beta * (1 - x1) * par.K * c4 - \
         par.mu * par.K * par.beta * (1 - x1) * par.r * par.alpha * c1 - par.mu * par.K * par.beta * (1 - x1) * par.alpha * c6 - \
        (par.mu ** 2) * ((c2) ** 2) -par. rho * par.beta * (1 - x1) * (par.K ** 2) * par.alpha * c5 - \
        par.rho * par.K * par.mu * c4 - par.rho * par.beta * (1 - x1) * (par.K ** 2) * par.alpha * c5
    d2 = par.Lambda * par.beta * (1 - x1) * par.K * par.alpha * c4 + \
         par.Lambda * par.beta * (1 - x1) * par.K * par.r * par.alpha * c1 + \
         par.Lambda * par.beta * (1 - x1) * par.K * par.alpha * c6 - \
         par.mu * (par.alpha ** 2) * par.beta * (1 - x1) * par.K * par.r * c1 - \
         par.mu * (par.alpha ** 2) * par.beta * (1 - x1) * par.K * c6 - \
         (par.mu ** 2) * par.alpha * ((c2) ** 2) - \
         par.mu * par.beta * (1 - x1) * par.K * par.r * (par.alpha ** 2) * c3 - \
         2 * (par.mu ** 2) * par.r * par.alpha * c2 - par.rho * par.K * par.mu * par.r * par.alpha * c1 - \
         par.rho *par. beta * (1 - x1) * (par.K ** 2) * ((c3) ** 2) * (par.alpha ** 2) - \
         par.rho * par.K * par.alpha * par.mu * c6
    d1 = par.Lambda * par.beta * (1 - x1) * par.K * par.r * (par.alpha ** 2) * c1 + \
         par.Lambda * par.beta * (1 - x1) * par.K * (par.alpha ** 2) * c6 + \
         par.Lambda * par.beta * (1 - x1) * par.K * par.r * (par.alpha ** 2) * c3 - \
         par.mu * (par.alpha ** 3) * par.beta * (1 - x1) * par.K * par.r * c3 - \
         2 * (par.mu ** 2) * par.r * (par.alpha ** 2) * c2 - ((par.mu * par.r * par.alpha) ** 2) - \
         par.rho * par.K * par.mu * par.r * (par.alpha ** 2) * c3
    d0 = (par.alpha * (par.mu * par.r * par.alpha) ** 2) * (R0 - 1)
    return c1, c2, c3, c4, c5, c6, d4, R0, d3, d2, d1, d0

