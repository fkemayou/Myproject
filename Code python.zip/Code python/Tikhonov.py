import numpy as np
from scipy.integrate import odeint
import functions as fu
import figures as fig


y0_reduit = [6000, 500, 100000]

# Conditions initiales pour le modèle original
y0_original = [6000, 500, 100000, 50000]  

# Temps
t = np.linspace(0, 150, 1001)

y_reduit = odeint(fu.modelreduit,y0_reduit,t)

# Résoudre le modèle original pour eps = 0.1
y_original_eps_01 = odeint(fu.modeloriginal_eps, y0_original, t, args=(0.1,))

# Résoudre le modèle original pour eps = 0.01
y_original_eps_001 = odeint(fu.modeloriginal_eps, y0_original, t, args=(0.01,))

# Résoudre le modèle original pour eps = 0.01
y_original_eps_0001 = odeint(fu.modeloriginal_eps, y0_original, t, args=(0.001,))

fig.figure_Tikhonov_plot(t, y_original_eps_01[:,0],  y_original_eps_001[:,0],
                    y_original_eps_0001[:,0], y_reduit[:,0], 
                    "Healthy roots $S$", r'$\bf{(a)}$', 
                    "healthy_roots_Tikhonov.pdf", 
                    show_legend=True)
fig.figure_Tikhonov_plot(t, y_original_eps_01[:,1],  y_original_eps_001[:,1], 
                    y_original_eps_0001[:,1], y_reduit[:,1], 
                    "Infected roots $I$",  r'$\bf{(b)}$', 
                    "infected_roots_Tikhonov.pdf")
fig.figure_Tikhonov_plot(t, y_original_eps_01[:,2],  y_original_eps_001[:,2],
                    y_original_eps_0001[:,2], y_reduit[:,2], 
                    "Total nematodes $N$",  r'$\bf{(c)}$', 
                    "total_nematodes_Tikhonov.pdf", format_yaxis=True)
fig.figure_Tikhonov_plot(t, y_original_eps_01[:,3],  y_original_eps_001[:,3], 
                    y_original_eps_0001[:,3], None, 
                    "Free nematodes $N_F$", r'$\bf{(d)}$', 
                    "free_nematodes_Tikhonov.pdf", format_yaxis=True)