import numpy as np
from scipy.integrate import odeint
import functions as fu
import figures as fig

#########################################  Forward birfucation

y0_1 = [6000, 1500, 900]
y0_2 = [6000,50,900]

t1 = np.linspace(0,300,1000)

y_1 = odeint(fu.modelreduit,y0_1,t1)
y_2 = odeint(fu.modelreduit,y0_2,t1)

fig.figure_Forward_stability_plot(t1, y_1[:,1], y_2[:,1],
                                  "forward_infected_roots_bi1.pdf")

  
######################################## Backward birfucation1

y0_1 = [200,12, 900] 
y0_2 = [200,40,900]

t2 = np.linspace(0,1500,3000)

y_1 = odeint(fu.modelreduitBb1,y0_1,t2)
y_2 = odeint(fu.modelreduitBb1,y0_2,t2)



fig.figure_Backward_bi_satbilty1_plot(t2, y_1[:,1], y_2[:,1],
                                   "backward_infected_roots_bi1.pdf")

########################################  Backward birfucation2

y0_1 = [200,2,900, 450]
y0_2 = [200,12,900,900/12]
y0_3 = [200,30,900, 90/4]
y0_4 = [200,40,900, 30]

#t = np.linspace(0,1500,3000)

y_1 = odeint(fu.fullmodel,y0_1,t2)
y_2 = odeint(fu.fullmodel,y0_2,t2)
y_3 = odeint(fu.fullmodel,y0_3,t2)
y_4 = odeint(fu.fullmodel,y0_4,t2)


fig.figure_Backward_bi_satbilty2_plot(t2, y_1[:,0], y_2[:,0], y_3[:,0], y_4[:,0], 
                    "Healthy roots $S$", r'$\bf{(a)}$', 
                    "backward_healthy_roots_bi2.pdf", 
                    show_legend=True)
fig.figure_Backward_bi_satbilty2_plot(t2, y_1[:,1], y_2[:,1], y_3[:,1], y_4[:,1], 
                    "Infected roots $I$",  r'$\bf{(b)}$', 
                    "backward_infected_roots_bi2.pdf")
fig.figure_Backward_bi_satbilty2_plot(t2, y_1[:,2], y_2[:,2], y_3[:,2], y_4[:,2], 
                    "Total nematodes $N$",  r'$\bf{(c)}$', 
                    "backward_total_nematodes_bi2.pdf", format_yaxis=True)
fig.figure_Backward_bi_satbilty2_plot(t2, y_1[:,3], y_2[:,3], y_3[:,3], y_4[:,3], 
                    "Infestation density $\mathcal{X}$", r'$\bf{(d)}$', 
                    "backward_infestation_density_bi2.pdf")

