import numpy as np
import functions as fu
import figures as fig

# Cas forward
vect_rh_F = np.arange(0.0001e-6, 0.107e-6, 0.1e-9)
sol1_F, sol2_F, sol3_F, sol4_F, Vect_R0_F, T0_F = fu.compute_bifurcation(vect_rh_F, 
                                                                         is_forward=True)
fig.figure_Forward_plot(T0_F, sol1_F, sol2_F, sol3_F, sol4_F, "forward_birfucation.pdf")

# Cas backward
vect_rh_B = np.arange(0.01e-6, 0.9e-5, 1e-9)
sol1_B, sol2_B, sol3_B, sol4_B, Vect_R0_B, T0_B = fu.compute_bifurcation(vect_rh_B, 
                                                                         is_forward=False)
fig.figure_Backward_plot(T0_B, sol1_B, sol2_B, sol3_B, sol4_B, "backward_birfucation.pdf")