import numpy as np
from scipy.optimize import fsolve, minimize
import params as  par 
import functions as fu
import figures as fig


# x1 = u, x2 = I

# Résoudre pour x2 en fonction de x1
def solve_for_x2(x1):
    c1, c2, c3, c4, c5, c6, d4, R0, d3, d2, d1, d0 = fu.calculate_coefficients_socp(x1)
    # Définition de l'équation dont la racine est cherchée
    g = lambda x2: d4 * x2 ** 4 + d3 * x2 ** 3 + d2 * x2 ** 2 + d1 * x2 + d0
    return fsolve(g, 1000)

# Contrainte d'égalité (fonction unique pour les deux)
def my_nonlcon(x):
    x1 = x[0]
    x2 = x[1]
    c1, c2, c3, c4, c5, c6, d4, R0, d3, d2, d1, d0 = fu.calculate_coefficients_socp(x1)
    # Définition de l'équation de la contrainte
    ceq = d4 * x2 ** 4 + d3 * x2 ** 3 + d2 * x2 ** 2 + d1 * x2 + d0
    return ceq

# Fonction objectif
def fun(x):
    x1 = x[0]
    x2 = solve_for_x2(x1)[0] # Résoudre pour x2 en fonction de x1
    N = par.K * x2 * ((par.r + par.c_rho * par.rho - par.nu_I) * x2 + \
                      (par.r - par.nu_I) * par.alpha) / ((par.r + par.c_rho * par.rho) * x2 + \
                                                         par.r * par.alpha)
    S = par.Lambda / (par.beta * (1 - x1) * N + par.mu) 
    return par.Bu * x1 - par.BS * S

# Résolution du problème d'optimisation
x0 = [0, 100]
res = minimize(fun, x0, bounds=[(0, 0.8), (0, None)], constraints={'type': 'eq', 'fun': my_nonlcon})

# Tracer la contrainte d'égalité et la fonction objectif
x1_values = np.linspace(0, 0.8, 100)
x2_values = np.array([solve_for_x2(x1) for x1 in x1_values])

J_values = np.array([fun([x1]) for x1 in x1_values])

# Tracer la contrainte
fig.figure_min_socp_plot(x1_values, x2_values, None, '$I$', 'Constraint')

# Tracer la fonction objectif
fig.figure_min_socp_plot(x1_values, None, J_values, '$\mathcal{J}(u)$', 'Objective function')


# # Affichage des résultats
print("Solution optimale :")
print("x1 optimal =", res.x[0])
print("x2 optimal =", solve_for_x2(res.x[0]))
print("Valeur de la fonction objectif =", res.fun)   