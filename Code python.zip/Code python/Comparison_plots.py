import numpy as np
from scipy.integrate import odeint
import functions as fu
import figures as fig
import params as par

tf = 300 # temps final
# Définition de la plage de temps
t = np.linspace(0, tf, 1001)

# Résolution du système d'équations différentielles
y_average = odeint(fu.controlled_model, par.y0, t, args=(0.412,))
y_withoutc = odeint(fu.controlled_model, par.y0, t, args=(0,))

# ⚠️⚠️⚠️⚠️ Spécifiez le chemin complet de vos fichiers
### OCP_data 
chemin_temps1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/discretization_times.export"
chemin_variableS1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/S.export"
chemin_variableI1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/I.export"
chemin_variableN1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/N.export"
chemin_variableu1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/u.export"

t1 = np.loadtxt(chemin_temps1)
S1 = np.loadtxt(chemin_variableS1)
I1 = np.loadtxt(chemin_variableI1)
N1 = np.loadtxt(chemin_variableN1)
u1 = np.loadtxt(chemin_variableu1)

# SOCP
chemin_temps2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/discretization_times.export"
chemin_variableS2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/S.export"
chemin_variableI2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/I.export"
chemin_variableN2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/N.export"
chemin_variableu2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/u.export"

t2 = np.loadtxt(chemin_temps2)
S2 = np.loadtxt(chemin_variableS2)
I2 = np.loadtxt(chemin_variableI2)
N2 = np.loadtxt(chemin_variableN2)
u2 = np.loadtxt(chemin_variableu2)

# COCP
chemin_temps3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/discretization_times.export"
chemin_variableS3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/S.export"
chemin_variableI3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/I.export"
chemin_variableN3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/N.export"
chemin_variableu3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/u.export"

t3 = np.loadtxt(chemin_temps3)
S3 = np.loadtxt(chemin_variableS3)
I3 = np.loadtxt(chemin_variableI3)
N3 = np.loadtxt(chemin_variableN3)
u3 = np.loadtxt(chemin_variableu3)


fig.figure_Comparison_plot(t, S1, S2, S3, y_average[:,0],  y_withoutc[:,0],
                    "Healthy roots $S$", r'$\bf{(a)}$', 
                    "comparison_healthy_roots.pdf", 
                    show_legend=False, is_healthy_roots_figure=True, 
                    is_control_figure=False)
fig.figure_Comparison_plot(t, I1, I2, I3, y_average[:,1],  y_withoutc[:,1],
                    "Infected roots $I$",  r'$\bf{(b)}$', 
                    "comparison_infected_roots.pdf", is_control_figure=False,
                    apply_ylim=True)
fig.figure_Comparison_plot(t, N1, N2, N3, y_average[:,2],  y_withoutc[:,2],
                    "Total nematodes $N$",  r'$\bf{(c)}$', 
                    "comparison_total_nematodes.pdf", 
                    format_yaxis=True,is_control_figure=False,
                    apply_ylim=True)
fig.figure_Comparison_plot(t, u1, u2, u3,  None, None,
                    "(Sub-)optimal control $u$", r'$\bf{(d)}$', 
                    "comparison_optimal_control.pdf", is_control_figure=True,
                    apply_ylim=True)



################# Calcul des couts de controle 

A1 = np.trapz(-par.BS * S1, t1)
A2 = np.trapz(par.Bu * u1, t1)
A3 = sum(u1) / 1001 
A = np.trapz(par.Bu * u1 - par.BS * S1, t1)

B1 = np.trapz(-par.BS * S2, t2)
B2 = np.trapz(par.Bu * u2, t2)
B = np.trapz(par.Bu * u2 - par.BS * S2, t1)

C1 = np.trapz(-par.BS * S3, t3)
C2 = np.trapz(par.Bu * u3, t3)
C = np.trapz(par.Bu * u3 - par.BS * S3, t1)

u_average = 0.412
D1 = np.trapz(-par.BS * y_average[:, 0], t)
D2 = tf*par.Bu * A3
D = D2 + D1

print("OCP - l'integrale de -BS*S:", A1)
print("OCP - l'integrale de Bu*u:", A2)
print("0CP - average:", A3)
print("0CP - l'integrale de Bu*u - BS*S:", A)


print("Static - OCP - l'integrale de -BS*S:", B1)
print("Static - OCP - l'integrale de Bu*u:", B2)
print("Static - OCP - l'integrale de Bu*u - BS*S:", B)

print("Constant - OCP - l'integrale de -BS*S:", C1)
print("Constant - oCP - l'integrale de Bu*u:", C2)
print("Constant - OCP - l'integrale de Bu*u - BS*S:", C)

print("average - OCP - l'integrale de -BS*S:", D1)
print("average - OCP - l'integrale de Bu*u:", D2)
print("average - OCP - l'integrale de Bu*u - BS*S:", D)


