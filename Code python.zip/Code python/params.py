# Model parameters
Lambda = 300  
rho = 0.0002 
mu = 0.05  
beta_I = beta = 0.0000001 
alpha = 60 
r = 0.15 
K = 1000 
nu_I= nu = 0.045 
c_rho = 400  
c_alpha = 100
beta_F = 0.0000001
nu_F = 0.0495
gamma = 0.02
eta = 0.0002
Bu = 7800
BS = 2

#Initial conditions
y0 = [100,100,1000]


