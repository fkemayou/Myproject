import numpy as np
from scipy.integrate import odeint
from scipy.optimize import differential_evolution
import figures as fig
import functions as fu
import params as par 

# Fixer une graine aléatoire pour la reproductibilité
np.random.seed(0) 


number_of_periods = 5
tf = 300  #temps final

t = np.linspace(0, 300, 1001)

# Définition de la fonction objectif à minimiser avec ajout de temps3
def objective_function(parameters):
    temps0, temps1, temps2, temps3 = parameters
    # Calcul de temps3 à partir de la relation donnée
    temps3 = tf - (temps0 + number_of_periods * (temps1 + temps2))
    
    y = odeint(fu.controlled_model_optimisation, par.y0, t, 
               args=(temps0, temps1, temps2, temps3))
    
    u_minus_B_times_S = [par.Bu*fu.control_sequence(ti, temps0, temps1, temps2, 
                                                    temps3) - par.BS * yi for ti, yi in zip(t, y[:, 0])] 
    integral_value = np.trapz(u_minus_B_times_S, t)
    
    return integral_value
# Définir les bornes des paramètres pour l'optimisation
bounds = [(0, 300), (0, 300), (0, 300), (0, 300)]

# Utiliser l'algorithme de Differential Evolution pour minimiser la fonction objectif
result = differential_evolution(objective_function, bounds)

# Récupérer les valeurs optimales pour temps0, temps1 et temps2
temps0_optimal, temps1_optimal, temps2_optimal, temps3_optimal = result.x
temps3_optimal = tf - (temps0_optimal +  number_of_periods * \
                        (temps1_optimal + temps2_optimal))

# Afficher les résultats
print("Optimal values:")
print("temps0:", temps0_optimal)
print("temps1:", temps1_optimal)
print("temps2:", temps2_optimal)
print("temps3:", temps3_optimal)

# Initialiser les conditions initiales et résoudre le système avec les paramètres optimaux
y = odeint(fu.controlled_model_optimisation, par.y0, t, 
           args=(temps0_optimal, temps1_optimal, temps2_optimal, temps3_optimal))
u_values = [fu.control_sequence(ti, temps0_optimal, temps1_optimal, 
                             temps2_optimal, temps3_optimal) for ti in t]


# Calculer la valeur de l'intégrale de Bu*u - BS * S + pénalité
u_minus_B_times_S = [par.Bu*fu.control_sequence(ti, temps0_optimal, temps1_optimal, 
                                         temps2_optimal, 
                                         temps3_optimal) - par.BS * yi for ti, yi in zip(t, y[:, 0])] 
integral_value = np.trapz(u_minus_B_times_S, t) 
print("Valeur de l'intégrale de Bu*u - BS * S:", integral_value)

# Calcul de Bu*u - BS * S pour chaque instant de temps
u_minus_B_times_Sp = [- par.BS * yi for ti, yi in zip(t, y[:, 0])] 

# Calcul de l'intégrale par la méthode des trapèzes
integral_valuep = np.trapz(u_minus_B_times_Sp, t)

print("Valeur de l'intégrale de - BS * S:", integral_valuep)
# Calcul de B_u*u - B_S * S pour chaque instant de temps
u_minus_B_times_Su = [par.Bu*fu.control_sequence(ti, temps0_optimal, temps1_optimal, 
                                          temps2_optimal,
                                          temps3_optimal)  for ti in zip(t)] 

# Calcul de l'intégrale par la méthode des trapèzes
integral_valueu = np.trapz(u_minus_B_times_Su, t)

print("Valeur de l'intégrale de B4*u:", integral_valueu)

# ⚠️⚠️⚠️⚠️ Spécifiez le chemin complet de vos fichiers 
# OCP 
chemin_temps1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/discretization_times.export"
chemin_variableS1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/S.export"
chemin_variableI1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/I.export"
chemin_variableN1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/N.export"
chemin_variableu1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP2text/u.export"

t1 = np.loadtxt(chemin_temps1)
S1 = np.loadtxt(chemin_variableS1)
I1 = np.loadtxt(chemin_variableI1)
N1 = np.loadtxt(chemin_variableN1)
u1 = np.loadtxt(chemin_variableu1)

# SOCP
chemin_temps2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/discretization_times.export"
chemin_variableS2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/S.export"
chemin_variableI2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/I.export"
chemin_variableN2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/N.export"
chemin_variableu2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exStaticOCPtext/u.export"

t2 = np.loadtxt(chemin_temps2)
S2 = np.loadtxt(chemin_variableS2)
I2 = np.loadtxt(chemin_variableI2)
N2 = np.loadtxt(chemin_variableN2)
u2 = np.loadtxt(chemin_variableu2)

# COCP
chemin_temps3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/discretization_times.export"
chemin_variableS3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/S.export"
chemin_variableI3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/I.export"
chemin_variableN3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/N.export"
chemin_variableu3 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exConstantOCPtext/u.export"

t3 = np.loadtxt(chemin_temps3)
S3 = np.loadtxt(chemin_variableS3)
I3 = np.loadtxt(chemin_variableI3)
N3 = np.loadtxt(chemin_variableN3)
u3 = np.loadtxt(chemin_variableu3)


y_average = odeint(fu.controlled_model, par.y0, t, args=(0.412,))
y_withoutc = odeint(fu.controlled_model, par.y0, t, args=(0,))

fig.figure_Periodic_plot(t, S1, S2, S3, y_average[:,0],  y_withoutc[:,0], y[:,0],
                    "Healthy roots $S$", r'$\bf{(a)}$', 
                    "periodic_healthy_roots.pdf", 
                    show_legend=False, is_healthy_roots_figure=True, 
                    is_control_figure=False)
fig.figure_Periodic_plot(t, I1, I2, I3, y_average[:,1],  y_withoutc[:,1], y[:,1],
                    "Infected roots $I$",  r'$\bf{(b)}$', 
                    "periodic_infected_roots.pdf", is_control_figure=False,
                    apply_ylim=True)
fig.figure_Periodic_plot(t, N1, N2, N3, y_average[:,2],  y_withoutc[:,2], y[:,2],
                    "Total nematodes $N$",  r'$\bf{(c)}$', 
                    "periodic_total_nematodes.pdf", 
                    format_yaxis=True,is_control_figure=False,
                    apply_ylim=True)
fig.figure_Periodic_plot(t, u1, u2, u3,  None, None, u_values,
                    "(Sub-)optimal control $u$", r'$\bf{(b)}$', 
                    "periodic_optimal_control.pdf", is_control_figure=True,
                    apply_ylim=True)