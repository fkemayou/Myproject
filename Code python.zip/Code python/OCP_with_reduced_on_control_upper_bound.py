import numpy as np
from scipy.integrate import odeint
import functions as fu
import figures as fig
import params as par


#Valeur de la penalite 
BI = 0

# Définition de la plage de temps
t = np.linspace(0, 300, 1001)

# Résolution du système d'équations différentielles
y_withoutc = odeint(fu.controlled_model, par.y0, t, args=(0,))

# ⚠️⚠️⚠️⚠️ Spécifiez le chemin complet de vos fichiers 
### OCP_data   
chemin_temps1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP3text/discretization_times.export"
chemin_variableS = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP3text/S.export"
chemin_variableI = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP3text/I.export"
chemin_variableN = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP3text/N.export"
chemin_variableu = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP3text/u.export"
chemin_adjointlambda1 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP3text/S_adjoint_state.export"
chemin_adjointlambda2 = r"C:\Users\PC\Documents\document\MyboxFranck\Articles\Article1\Code python\exOCP3text/I_adjoint_state.export"
# Importez les données depuis les fichiers
t1 = np.loadtxt(chemin_temps1)
S = np.loadtxt(chemin_variableS)
I = np.loadtxt(chemin_variableI)
N = np.loadtxt(chemin_variableN)
u = np.loadtxt(chemin_variableu)
lambda1 = np.loadtxt(chemin_adjointlambda1)
lambda2 = np.loadtxt(chemin_adjointlambda2)


fig.figure_OCP_plot(t, S, y_withoutc[:,0],
                    "Healthy roots $S$", r'$\bf{(a)}$', 
                    "ocp_with_reduced_on _UB_healthy_roots.pdf", 
                    show_legend=False, is_healthy_roots_figure=True)
fig.figure_OCP_plot(t, I, y_withoutc[:,1],
                    "Infected roots $I$",  r'$\bf{(b)}$', 
                    "ocp_with_reduced_on _UB_infected_roots.pdf",
                    apply_ylim=True)
fig.figure_OCP_plot(t, N, y_withoutc[:,2],
                    "Total nematodes $N$",  r'$\bf{(c)}$', 
                    "ocp_with_reduced_on _UB_total_nematodes.pdf", 
                    format_yaxis=True,
                    apply_ylim=True)
fig.figure_OCP_plot(t, u, None, 
                    "Optimal control $u^{\star}$", r'$\bf{(d)}$', 
                    "ocp_with_reduced_on _UB_optimal_control.pdf", 
                    apply_ylim=True)



################# Calcul des couts de controle 


A1 = np.trapz(-par.BS * S, t1)
A2 = np.trapz(par.Bu * u, t1)
A3 = BI*I[-1]
A4 = sum(u) / 1001 
A = A1 + A2 + A3


print("OCP - l'integrale de -BS*S:", A1)
print("OCP - l'integrale de Bu*u:", A2)
print("OCP - penalite:", A3)
print("0CP - average:", A4)
print("0CP - l'integrale de Bu*u - BS*S + penalite:", A)



